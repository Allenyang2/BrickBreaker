package edu.umb.cs443.brickbreaker;

import android.graphics.RectF;

public class Bricks
{

private RectF rect;

private boolean isVisible;

public Bricks(int row, int column, int width, int height){

        isVisible = true;

        int buffer = 2;

        rect = new RectF(column * width + buffer,
        row * height + buffer,
        column * width + width - buffer,
        row * height + height - buffer);
        }

public RectF getRect(){
        return this.rect;
        }

public void setInvisible(){
        isVisible = false;
        }

public boolean getVisibility(){
        return isVisible;
        }
        }
