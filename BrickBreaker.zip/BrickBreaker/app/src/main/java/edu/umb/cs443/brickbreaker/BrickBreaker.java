package edu.umb.cs443.brickbreaker;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class BrickBreaker extends Activity {

    BreakoutView bbView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bbView = new BreakoutView(this);
        setContentView(bbView);
    }

    class BreakoutView extends SurfaceView implements Runnable {

        int xScreenWidth;
        int yScreenHeight;
        int numBricks = 0;
        int score = 0;
        int lives = 3;

        Player paddle;
        Ball ball;
        Bricks[] bricks = new Bricks[200];

        SurfaceHolder Holder;

        long fps;
        private long fpsCalc;

        volatile boolean gameState;
        boolean paused = true;

        Canvas canvas;
        Paint paint;

        Thread mThread = null;

        public BreakoutView(Context context) {
            super(context);
            Holder = getHolder();
            paint = new Paint();

            Display display = getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);

            xScreenWidth = size.x;
            yScreenHeight = size.y;

            paddle = new Player(xScreenWidth, yScreenHeight);
            ball = new Ball(xScreenWidth, yScreenHeight);

            startGame();
        }

        public void startGame() {

            ball.reset(xScreenWidth, yScreenHeight);
            paddle.reset(xScreenWidth, yScreenHeight);

            int brickWidth = xScreenWidth / 10;
            int brickHeight = yScreenHeight / 12;
            numBricks = 0;

            for (int column = 0; column < 11; column++) {
                for (int row = 0; row < 4; row++) {
                    bricks[numBricks] = new Bricks(row, column, brickWidth, brickHeight);
                    numBricks++;
                }
            }
            if (lives == 0) {
                score = 0;
                lives = 3;
            }
        }

        @Override
        public void run() {
            while (gameState) {
                long startFrameTime = System.currentTimeMillis();
                if (!paused) {
                    update();
                }
                draw();
                fpsCalc = System.currentTimeMillis() - startFrameTime;
                if (fpsCalc >= 1) {
                    fps = 1000 / fpsCalc;
                }

            }

        }
        public void update() {
            paddle.update(fps);
            ball.update(fps,score);

            for (int i = 0; i < numBricks; i++) {
                if (bricks[i].getVisibility()) {
                    if (RectF.intersects(bricks[i].getRect(), ball.getRect())) {
                        bricks[i].setInvisible();
                        ball.reverseY();
                        score = score + 1;
                    }
                }
            }
            if(ball.getRect().bottom > yScreenHeight - 30 && (ball.getRect().right >= paddle.x && ball.getRect().left <= paddle.x + 130)){
                Log.d("Ball", "collision");
               Log.d("hello", "world");
                ball.randomXVelocity();
                ball.reverseY();
                ball.clearY(paddle.getRect().top - 2);
            }
            if (ball.getRect().bottom > yScreenHeight) {
                ball.reverseY();
                ball.clearY(yScreenHeight - 2);
                lives--;

                if (lives == 0) {
                    paused = true;
                    startGame();
                }
            }
            if (ball.getRect().top < 0)

            {
                ball.reverseY();
                ball.clearY(12);
            }
            if (ball.getRect().left < 0)

            {
                ball.reverseX();
                ball.clearX(2);
            }
            if (ball.getRect().right > xScreenWidth - 30) {

                ball.reverseX();
                ball.clearX(xScreenWidth - 62);

            }
            if (score == numBricks)
            {
                paused = true;
                startGame();
            }
        }
        public void draw() {
            if (Holder.getSurface().isValid()) {
                canvas = Holder.lockCanvas();
                canvas.drawColor(Color.argb(255, 206, 216, 30));
                paint.setColor(Color.argb(255, 0, 0, 0));
                canvas.drawRect(paddle.getRect(), paint);
                canvas.drawRect(ball.getRect(), paint);
                paint.setColor(Color.argb(255, 100, 54, 206));

                for (int i = 0; i < numBricks; i++) {
                    if (bricks[i].getVisibility()) {
                        canvas.drawRect(bricks[i].getRect(), paint);
                    }
                }
                paint.setColor(Color.argb(255, 0, 0, 0));
                paint.setTextSize(40);
                canvas.drawText("Score: " + score + "   Lives: " + lives, 10, 400, paint);
                if (score == numBricks * 10) {
                    paint.setTextSize(90);
                    canvas.drawText("You've won the game!", 10, yScreenHeight / 2, paint);
                }
                Holder.unlockCanvasAndPost(canvas);
            }
        }

        public void resume() {
            gameState = true;
            mThread = new Thread(this);
            mThread.start();
        }
        @Override
        public boolean onTouchEvent(MotionEvent motionEvent) {
            switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_DOWN:
                    paused = false;
                    if (motionEvent.getX() > xScreenWidth / 4) {

                        paddle.setMovementState(paddle.rightMoving);
                    } else {
                        paddle.setMovementState(paddle.leftMoving);
                    }

                    break;
                case MotionEvent.ACTION_UP:

                    paddle.setMovementState(paddle.notMoving);
                    break;
            }
                return true;
            }
    }
    @Override
    protected void onResume() {
        super.onResume();
        bbView.resume();
    }
}


