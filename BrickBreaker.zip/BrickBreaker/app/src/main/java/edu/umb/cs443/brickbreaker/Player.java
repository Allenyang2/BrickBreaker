package edu.umb.cs443.brickbreaker;

import android.graphics.RectF;

public class Player {
    private RectF rect;
    private float length = 130;
    private float height = 20;
    public int myscreenX;
    public int myscreenY;
    public float x;
    public float y;
    private float paddleSpeed;
    public final int notMoving = 0;
    public final int leftMoving = 1;
    public final int rightMoving = 2;
    private int movePaddle = notMoving;

    public Player(int xScreenSize, int yScreenSize){
        myscreenX = xScreenSize;
        myscreenY = yScreenSize;
        x = xScreenSize / 2;
        y = yScreenSize - 20;

        rect = new RectF(x, y, x + length, y + height);
        paddleSpeed = 950;
    }

    public RectF getRect(){
        return rect;
    }

    public void setMovementState(int state){
        movePaddle = state;
    }

    public void update(long fps){

        if(movePaddle == leftMoving){
            x = x - paddleSpeed / fps;
        }
        if(movePaddle == rightMoving){
            x = x + paddleSpeed / fps;
        }
        rect.left = x;
        rect.right = x + length;
        paddleCheck();
    }
    public void paddleCheck(){
        if(x > myscreenX - length){
            x = myscreenX - length;
        }
        if(x < 0){
            x = 1;
        }
    }
    public void reset(int x, int y){
        rect.left = x / 2;
        rect.top = y - 20;
        rect.right = x / 2 + length;
        rect.bottom = y - 20 - height;
    }

}
