package edu.umb.cs443.brickbreaker;

import java.util.Random;
import android.graphics.RectF;

public class Ball {
    RectF rect;
    float xVelocity;
    float yVelocity;
    float ballWidth = 30;
    float ballHeight = 30;

    public Ball(int screenX, int screenY){
        xVelocity = 200;
        yVelocity = -400;
        rect = new RectF();

    }

    public RectF getRect(){
        return rect;
    }

    public void update(long fps, int score){
        float newScore = (float)score;
        float adjX = (float) (xVelocity * (1.0+(newScore/10.0)));
        float adjY = (float)( yVelocity * (1+(newScore/10.0)));
        rect.left = rect.left + ((adjX) / fps);
        rect.top = rect.top + ((adjY) / fps);
        rect.right = rect.left + ballWidth;
        rect.bottom = rect.top - ballHeight;

    }

    public void reverseY(){
        yVelocity = -yVelocity;
    }

    public void reverseX(){
        xVelocity = - xVelocity;
    }

    public void randomXVelocity(){
        Random generator = new Random();
        int answer = generator.nextInt(2);

        if(answer == 0){
            reverseX();
        }
    }

    public void clearY(float y){
        rect.bottom = y;
        rect.top = y - ballHeight;
    }

    public void clearX(float x){
        rect.left = x;
        rect.right = x + ballWidth;
    }

    public void reset(int x, int y){
        rect.left = x / 2;
        rect.top = y - 20;
        rect.right = x / 2 + ballWidth;
        rect.bottom = y - 20 - ballHeight;
    }

}
